#ifndef _PGMIO_H
#define _PGMIO_H
#include "image.h"

void ReadImage(const char *, Image *);
void WriteImage(const char *, Image);
#endif
